# Kartu Rimba - jadikan APK

## Cara paling mudah (tanpa install apa pun, lewat GitHub)
1. Buat akun GitHub, lalu buat repository baru (boleh private).
2. Upload SEMUA isi folder ini (termasuk folder .github dan www) ke repository tersebut.
3. Buka tab Actions > "Build APK" > Run workflow. Tunggu sekitar 5-10 menit.
4. Buka hasil run-nya, unduh artifact "kartu-rimba-apk" (isinya app-debug.apk).
5. Pindahkan ke HP, buka file APK-nya, izinkan "install dari sumber tidak dikenal".

## Cara lewat Android Studio
npm install
npx cap add android
(di android/app/src/main/AndroidManifest.xml tambahkan android:screenOrientation="sensorLandscape" pada tag <activity>)
npx cap sync android
npx cap open android   -> Build > Build APK(s)

## Catatan
- Game ada di www/index.html. Ubah di sana lalu jalankan build lagi.
- Mode vs bot dan AI jalan offline. Mode "Main dengan Teman" butuh internet: satu orang buat ruangan (dapat kode 4 karakter), yang lain gabung dengan kode itu. Koneksi memakai WebRTC lewat server perantara gratis PeerJS. Di jaringan tertentu (misalnya data seluler yang ketat) koneksi bisa gagal; coba WiFi yang sama atau hotspot.
- Ini APK debug (untuk dipasang sendiri). Untuk Play Store perlu APK/AAB yang ditandatangani.
